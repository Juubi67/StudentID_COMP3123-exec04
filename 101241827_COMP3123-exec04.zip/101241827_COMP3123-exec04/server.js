const express = require("express");
const app = express();
const port = process.env.PORT || 3000;

// Middleware to parse JSON requests
app.use(express.json());

// Define your routes
app.get("/hello", (req, res) => {
  res.send("Hello Express JS");
});

app.get("/user", (req, res) => {
  const { firstname, lastname } = req.query;
  const userData = {
    firstname: firstname || "Pritesh",
    lastname: lastname || "Patel",
  };
  res.json(userData);
});

app.post("/user/:firstname/:lastname", (req, res) => {
  const { firstname, lastname } = req.params;
  const userData = {
    firstname: firstname || "Pritesh",
    lastname: lastname || "Patel",
  };
  res.json(userData);
});

// Start the Express server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
